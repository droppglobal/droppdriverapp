/*Driver App Configuration*/

var krms_driver_config ={			
	'ApiUrl':"http://dropp.com.ng/driver/api",		
	'DialogDefaultTitle':"Dropp Driver App",
	'mapboxToken' : 'pk.eyJ1Ijoia2luZ3F1ZXN0IiwiYSI6ImNqcXY1ZnVydzBwaDM0M255MmhkdXg3bTcifQ.Pm0uqcsBMcTmSeiqlRtikg',

	'APIHasKey':"AIzaSyDZhKiMzjGBenelV3oV862slmUOmRicjd8",
	'debug': false
};